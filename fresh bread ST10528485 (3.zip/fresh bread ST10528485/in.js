 /* ============================================================================
   GOLDEN CRUST BAKERY — site enhancements
   Vanilla JavaScript, no dependencies, no external requests.
   Reads colors straight from the existing index.css custom properties
   (--gold, --cream, --brown-dark, etc.) so every new element it creates
   blends into the current design automatically.

   This file does NOT touch your HTML or CSS. To activate it, add one
   line just before the closing </body> tag on every page:

       <script src="script.js" defer></script>

   Everything below checks that an element exists before using it, so the
   same script.js can be linked from every page (home, about, service,
   contact, product) without throwing errors on pages that don't have a
   given feature (e.g. only product.html has .product-card buttons).
   ============================================================================ */

(function () {
  "use strict";

  document.addEventListener("DOMContentLoaded", init);

  function init() {
    injectDynamicStyles();
    fadeInMain();
    initActiveNav();
    initHeaderScroll();
    initImageReveal();
    initScrollReveal();
    initBackToTop();
    initCart();
    initContactEnhancements();
  }

  /* ==========================================================================
     0. ONE small stylesheet for the new widgets this script creates
        (cart, toast, back-to-top, status pill, tel links). It only ever
        uses var(--...) tokens already defined in index.css, so it can
        never clash with or override your existing rules.
     ========================================================================== */
  function injectDynamicStyles() {
    if (document.getElementById("gcb-dynamic-styles")) return;

    const css = `
      /* fade the page in on load */
      main.gcb-fade-init { opacity: 0; transform: translateY(8px); }
      main.gcb-fade-in   { opacity: 1; transform: translateY(0); transition: opacity .5s ease, transform .5s ease; }

      /* active nav link */
      nav a.gcb-active {
        color: var(--gold-light) !important;
        border-color: var(--gold-light) !important;
        background-color: rgba(224, 184, 90, 0.14) !important;
      }

      /* header gets a touch more depth once you scroll */
      header.gcb-scrolled {
        box-shadow: 0 4px 22px var(--shadow);
      }

      /* logo acts like a "home" link */
      header img.gcb-logo-link { cursor: pointer; }

      /* ---- cart ---- */
      .gcb-cart-wrap { position: relative; margin-left: 6px; }
      .gcb-cart-toggle {
        display: flex; align-items: center; gap: 6px;
        background: transparent;
        border: 1px solid var(--gold);
        color: var(--cream);
        padding: 8px 14px;
        border-radius: var(--radius);
        font-family: var(--font-body);
        font-size: 0.78rem;
        font-weight: 700;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        cursor: pointer;
        box-shadow: none;
        transition: background-color .25s ease, color .25s ease, transform .2s ease;
      }
      .gcb-cart-toggle:hover {
        background-color: rgba(224, 184, 90, 0.12);
        color: var(--gold-light);
        transform: translateY(-1px);
      }
      .gcb-cart-count {
        background: var(--gold);
        color: var(--white);
        font-size: 0.7rem;
        font-weight: 900;
        min-width: 18px;
        height: 18px;
        padding: 0 5px;
        border-radius: 999px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        line-height: 1;
      }
      .gcb-cart-panel {
        position: absolute;
        top: calc(100% + 12px);
        right: 0;
        width: 290px;
        max-height: 360px;
        overflow-y: auto;
        background: var(--cream);
        border: 1px solid var(--beige);
        border-top: 3px solid var(--gold);
        border-radius: var(--radius);
        box-shadow: 0 12px 36px var(--shadow);
        padding: 14px;
        z-index: 200;
        display: none;
      }
      .gcb-cart-panel.gcb-open { display: block; animation: gcb-drop .2s ease; }
      @keyframes gcb-drop { from { opacity: 0; transform: translateY(-6px); } to { opacity: 1; transform: translateY(0); } }
      .gcb-cart-panel h4 {
        all: unset;
        display: block;
        font-family: var(--font-heading);
        color: var(--brown-dark);
        font-size: 1rem;
        font-weight: 700;
        margin-bottom: 8px;
        padding-bottom: 6px;
        border-bottom: 1px solid var(--beige);
      }
      .gcb-cart-empty { color: var(--charcoal-mid); font-size: 0.88rem; font-style: italic; }
      .gcb-cart-item {
        display: flex; align-items: center; justify-content: space-between;
        gap: 8px; padding: 8px 0; border-bottom: 1px dashed var(--beige);
        font-size: 0.85rem; color: var(--charcoal-mid);
      }
      .gcb-cart-item:last-of-type { border-bottom: none; }
      .gcb-cart-item-name { font-weight: 700; color: var(--brown-dark); }
      .gcb-cart-item-meta { font-size: 0.78rem; opacity: 0.85; }
      .gcb-cart-remove {
        background: none; border: none; box-shadow: none;
        color: var(--gold-dark); font-size: 0.95rem; font-weight: 900;
        cursor: pointer; padding: 0 4px; line-height: 1;
        text-transform: none; letter-spacing: 0;
      }
      .gcb-cart-remove:hover { color: var(--brown-dark); transform: none; }
      .gcb-cart-total {
        display: flex; justify-content: space-between; align-items: center;
        margin-top: 10px; padding-top: 10px; border-top: 2px solid var(--gold);
        font-weight: 900; color: var(--brown-dark); font-family: var(--font-heading);
      }
      .gcb-cart-clear {
        width: 100%; margin-top: 10px; padding: 9px 0;
        font-size: 0.72rem;
      }

      /* ---- toast ---- */
      .gcb-toast-stack {
        position: fixed; top: 96px; right: 20px; z-index: 999;
        display: flex; flex-direction: column; gap: 10px;
        pointer-events: none;
      }
      .gcb-toast {
        background: var(--charcoal);
        color: var(--cream);
        border-left: 4px solid var(--gold);
        padding: 12px 18px;
        border-radius: var(--radius);
        font-size: 0.85rem;
        box-shadow: 0 8px 24px var(--shadow);
        opacity: 0;
        transform: translateX(30px);
        transition: opacity .35s ease, transform .35s ease;
      }
      .gcb-toast.gcb-show { opacity: 1; transform: translateX(0); }

      /* ---- back to top ---- */
      .gcb-back-to-top {
        position: fixed; bottom: 26px; right: 24px; z-index: 150;
        width: 46px; height: 46px; border-radius: 50%;
        background: var(--gold);
        color: var(--white);
        display: flex; align-items: center; justify-content: center;
        font-size: 1.2rem; line-height: 1;
        box-shadow: 0 4px 16px var(--shadow);
        opacity: 0; visibility: hidden; transform: translateY(10px);
        transition: opacity .3s ease, transform .3s ease, background-color .25s ease, visibility .3s;
        padding: 0;
      }
      .gcb-back-to-top.gcb-visible { opacity: 1; visibility: visible; transform: translateY(0); }
      .gcb-back-to-top:hover { background: var(--gold-dark); transform: translateY(-3px); }

      /* ---- contact: open/closed pill ---- */
      .gcb-status-pill {
        display: inline-flex; align-items: center; gap: 6px;
        font-family: var(--font-body);
        font-size: 0.75rem; font-weight: 700; letter-spacing: 0.08em;
        text-transform: uppercase;
        padding: 5px 12px; border-radius: 999px;
        margin: 6px 0 14px;
      }
      .gcb-status-pill.gcb-open-now { background: rgba(196,154,60,0.15); color: var(--gold-dark); border: 1px solid var(--gold); }
      .gcb-status-pill.gcb-closed-now { background: rgba(62,36,16,0.08); color: var(--brown); border: 1px solid var(--beige-mid); }
      .gcb-status-dot { width: 8px; height: 8px; border-radius: 50%; background: currentColor; }

      /* ---- contact: clickable phone numbers ---- */
      a.gcb-tel-link {
        color: var(--gold-dark);
        font-weight: 700;
        text-decoration: none;
        border-bottom: 1px dotted var(--gold-dark);
        transition: color .2s ease;
      }
      a.gcb-tel-link:hover { color: var(--brown-dark); }
    `;

    const styleTag = document.createElement("style");
    styleTag.id = "gcb-dynamic-styles";
    styleTag.textContent = css;
    document.head.appendChild(styleTag);
  }

  /* ==========================================================================
     1. Gentle fade-in for <main> on every page load
     ========================================================================== */
  function fadeInMain() {
    const main = document.querySelector("main");
    if (!main) return;
    main.classList.add("gcb-fade-init");
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        main.classList.remove("gcb-fade-init");
        main.classList.add("gcb-fade-in");
      });
    });
  }

  /* ==========================================================================
     2. Highlight the nav link for the page you're currently on
     ========================================================================== */
  function initActiveNav() {
    const links = document.querySelectorAll("nav a");
    if (!links.length) return;

    let current = window.location.pathname.split("/").pop().toLowerCase();
    if (current === "") current = "home.html";

    links.forEach((link) => {
      const linkFile = link.getAttribute("href").split("/").pop().toLowerCase();
      if (linkFile === current) {
        link.classList.add("gcb-active");
        link.setAttribute("aria-current", "page");
      }
    });

    // Logo doubles as a "back to home" shortcut
    const logo = document.querySelector("header img");
    if (logo) {
      logo.classList.add("gcb-logo-link");
      logo.addEventListener("click", () => {
        window.location.href = "home.html";
      });
    }
  }

  /* ==========================================================================
     3. Add a touch more depth to the sticky header once the page scrolls
     ========================================================================== */
  function initHeaderScroll() {
    const header = document.querySelector("header");
    if (!header) return;

    const update = () => {
      header.classList.toggle("gcb-scrolled", window.scrollY > 12);
    };
    update();
    window.addEventListener("scroll", update, { passive: true });
  }

  /* ==========================================================================
     4. Soft fade for images as they load (logo, product photos, icons)
     ========================================================================== */
  function initImageReveal() {
    const images = document.querySelectorAll("main img, header img");
    images.forEach((img) => {
      if (img.complete && img.naturalWidth > 0) return; // already loaded, leave alone
      img.style.opacity = "0";
      img.style.transition = "opacity .5s ease";
      img.addEventListener("load", () => {
        img.style.opacity = "1";
      });
      img.addEventListener("error", () => {
        img.style.opacity = "1";
      });
    });
  }

  /* ==========================================================================
     5. Fade + rise elements into view as you scroll down the page
     ========================================================================== */
  function initScrollReveal() {
    const targets = document.querySelectorAll(
      "main h1, main h2, main h3, main h4, main h5, main h6, main p, main video, main iframe, .product-card"
    );
    if (!targets.length || !("IntersectionObserver" in window)) return;

    targets.forEach((el, i) => {
      el.style.opacity = "0";
      el.style.transform = "translateY(20px)";
      el.style.transition = `opacity .6s ease ${Math.min(i * 0.05, 0.3)}s, transform .6s ease ${Math.min(i * 0.05, 0.3)}s`;
    });

    const observer = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.style.opacity = "1";
            entry.target.style.transform = "translateY(0)";
            obs.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -40px 0px" }
    );

    targets.forEach((el) => observer.observe(el));
  }

  /* ==========================================================================
     6. Back-to-top button
     ========================================================================== */
  function initBackToTop() {
    const btn = document.createElement("button");
    btn.className = "gcb-back-to-top";
    btn.type = "button";
    btn.setAttribute("aria-label", "Back to top");
    btn.innerHTML = "&uarr;";
    document.body.appendChild(btn);

    btn.addEventListener("click", () => {
      window.scrollTo({ top: 0, behavior: "smooth" });
    });

    window.addEventListener(
      "scroll",
      () => {
        btn.classList.toggle("gcb-visible", window.scrollY > 420);
      },
      { passive: true }
    );
  }

  /* ==========================================================================
     7. Shopping cart for product.html (persists between visits)
     ========================================================================== */
  function initCart() {
    const buyButtons = document.querySelectorAll(".product-card button");
    if (!buyButtons.length) return; // not the product page

    const STORAGE_KEY = "gcb_cart";
    let cart = readCart();

    const header = document.querySelector("header");
    const cartWrap = document.createElement("div");
    cartWrap.className = "gcb-cart-wrap";
    cartWrap.innerHTML = `
      <button type="button" class="gcb-cart-toggle" aria-haspopup="true" aria-expanded="false">
        Cart <span class="gcb-cart-count">0</span>
      </button>
      <div class="gcb-cart-panel"></div>
    `;
    if (header) header.appendChild(cartWrap);

    const toggleBtn = cartWrap.querySelector(".gcb-cart-toggle");
    const countEl = cartWrap.querySelector(".gcb-cart-count");
    const panelEl = cartWrap.querySelector(".gcb-cart-panel");

    toggleBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      const open = panelEl.classList.toggle("gcb-open");
      toggleBtn.setAttribute("aria-expanded", open ? "true" : "false");
    });

    document.addEventListener("click", (e) => {
      if (!cartWrap.contains(e.target)) panelEl.classList.remove("gcb-open");
    });

    buyButtons.forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        const card = btn.closest(".product-card");
        if (!card) return;

        const nameEl = card.querySelector("h1,h2,h3,h4,h5,h6,h7");
        const priceEl = card.querySelector(".price");
        const name = nameEl ? nameEl.textContent.trim() : "Item";
        const priceText = priceEl ? priceEl.textContent.trim() : "R0";
        const price = parseFloat(priceText.replace(/[^\d.]/g, "")) || 0;

        const existing = cart.find((item) => item.name === name);
        if (existing) existing.qty += 1;
        else cart.push({ name: name, price: price, qty: 1 });

        writeCart();
        renderPanel();
        showToast(`${name} added to your cart — ${priceText}`);
        pulse(btn);
      });
    });

    renderPanel();

    function readCart() {
      try {
        return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
      } catch (err) {
        return [];
      }
    }

    function writeCart() {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
      } catch (err) {
        /* storage unavailable — cart just won't persist, no crash */
      }
    }

    function totalCount() {
      return cart.reduce((sum, item) => sum + item.qty, 0);
    }

    function totalPrice() {
      return cart.reduce((sum, item) => sum + item.qty * item.price, 0);
    }

    function renderPanel() {
      countEl.textContent = String(totalCount());

      if (!cart.length) {
        panelEl.innerHTML = `
          <h4>Your Cart</h4>
          <p class="gcb-cart-empty">Nothing in here yet — pick a loaf!</p>
        `;
        return;
      }

      const rows = cart
        .map(
          (item, idx) => `
          <div class="gcb-cart-item">
            <span>
              <span class="gcb-cart-item-name">${escapeHTML(item.name)}</span><br>
              <span class="gcb-cart-item-meta">Qty ${item.qty} &times; R${item.price.toFixed(2)}</span>
            </span>
            <button type="button" class="gcb-cart-remove" data-idx="${idx}" aria-label="Remove ${escapeHTML(item.name)}">&times;</button>
          </div>
        `
        )
        .join("");

      panelEl.innerHTML = `
        <h4>Your Cart</h4>
        ${rows}
        <div class="gcb-cart-total"><span>Total</span><span>R${totalPrice().toFixed(2)}</span></div>
        <button type="button" class="gcb-cart-clear">Clear Cart</button>
      `;

      panelEl.querySelectorAll(".gcb-cart-remove").forEach((removeBtn) => {
        removeBtn.addEventListener("click", (e) => {
          e.stopPropagation();
          const idx = Number(removeBtn.getAttribute("data-idx"));
          cart.splice(idx, 1);
          writeCart();
          renderPanel();
        });
      });

      const clearBtn = panelEl.querySelector(".gcb-cart-clear");
      if (clearBtn) {
        clearBtn.addEventListener("click", (e) => {
          e.stopPropagation();
          cart = [];
          writeCart();
          renderPanel();
        });
      }
    }
  }

  function pulse(el) {
    el.style.transition = "transform .18s ease";
    el.style.transform = "scale(0.94)";
    setTimeout(() => {
      el.style.transform = "scale(1)";
    }, 140);
  }

  function escapeHTML(str) {
    return str.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  /* ==========================================================================
     8. Toast notifications (used by the cart, reusable elsewhere)
     ========================================================================== */
  function showToast(message) {
    let stack = document.querySelector(".gcb-toast-stack");
    if (!stack) {
      stack = document.createElement("div");
      stack.className = "gcb-toast-stack";
      document.body.appendChild(stack);
    }
    const toast = document.createElement("div");
    toast.className = "gcb-toast";
    toast.textContent = message;
    stack.appendChild(toast);

    requestAnimationFrame(() => toast.classList.add("gcb-show"));

    setTimeout(() => {
      toast.classList.remove("gcb-show");
      setTimeout(() => toast.remove(), 350);
    }, 2600);
  }

  /* ==========================================================================
     9. Contact page extras: open/closed status + clickable phone numbers
     ========================================================================== */
  function initContactEnhancements() {
    addStatusPill();
    linkifyPhoneNumbers();
  }

  function addStatusPill() {
    const headings = document.querySelectorAll("main h5");
    let tradingHeading = null;
    headings.forEach((h) => {
      if (/trading hours/i.test(h.textContent)) tradingHeading = h;
    });
    if (!tradingHeading) return; // not the contact page

    const now = new Date();
    const day = now.getDay(); // 0 = Sunday
    const minutes = now.getHours() * 60 + now.getMinutes();
    const isSunday = day === 0;

    const openMinutes = isSunday ? 7 * 60 : 6 * 60;
    const closeMinutes = isSunday ? 14 * 60 : 17 * 60;
    const isOpen = minutes >= openMinutes && minutes < closeMinutes;

    const pill = document.createElement("p");
    pill.className = "gcb-status-pill " + (isOpen ? "gcb-open-now" : "gcb-closed-now");
    pill.innerHTML = `<span class="gcb-status-dot"></span>${isOpen ? "Open now" : "Closed now"}`;
    tradingHeading.insertAdjacentElement("afterend", pill);
  }

  function linkifyPhoneNumbers() {
    const main = document.querySelector("main");
    if (!main) return;

    // Matches sequences like "079 801 5124", "011 555 6790", "87 564 7895"
    const phonePattern = /(\+?\d[\d\s]{7,}\d)/g;

    const walker = document.createTreeWalker(main, NodeFilter.SHOW_TEXT, null);
    const candidates = [];
    let node;
    while ((node = walker.nextNode())) {
      if (node.parentNode && node.parentNode.closest("a")) continue; // skip if already a link
      if (phonePattern.test(node.nodeValue)) candidates.push(node);
      phonePattern.lastIndex = 0;
    }

    candidates.forEach((textNode) => {
      const text = textNode.nodeValue;
      const frag = document.createDocumentFragment();
      let lastIndex = 0;
      let match;
      phonePattern.lastIndex = 0;

      while ((match = phonePattern.exec(text))) {
        const digits = match[0].replace(/\s/g, "");
        if (digits.replace(/\D/g, "").length < 9) continue; // skip short false-positives like postal codes

        frag.appendChild(document.createTextNode(text.slice(lastIndex, match.index)));

        const a = document.createElement("a");
        a.href = "tel:" + digits;
        a.className = "gcb-tel-link";
        a.textContent = match[0];
        frag.appendChild(a);

        lastIndex = match.index + match[0].length;
      }

      if (lastIndex === 0) return; // nothing valid actually matched
      frag.appendChild(document.createTextNode(text.slice(lastIndex)));
      textNode.parentNode.replaceChild(frag, textNode);
    });
  }
})();